## 生成证书
openssl genrsa -out vault-ca.key 4096

openssl req -x509 -new -nodes -sha512 -days 3650 \
 -subj "/C=CN/ST=Beijing/L=Beijing/CN=vault.ragnarokrevival.com" \
 -key vault-ca.key \
 -out vault-ca.pem
 

openssl genrsa -out vault-key.pem 4096

openssl req -sha512 -new \
    -subj "/C=CN/ST=Beijing/L=Beijing/CN=vault.ragnarokrevival.com" \
    -key vault-key.pem \
    -out vault-cert.csr
    

cat > v3.ext <<-EOF
authorityKeyIdentifier=keyid,issuer
basicConstraints=CA:FALSE
keyUsage = digitalSignature, nonRepudiation, keyEncipherment, dataEncipherment
extendedKeyUsage = serverAuth
subjectAltName = @alt_names

[alt_names]
DNS.1=vault.ragnarokrevival.com
EOF


openssl x509 -req -sha512 -days 3650 \
    -extfile v3.ext \
    -CA vault-ca.pem -CAkey vault-ca.key -CAcreateserial \
    -in vault-cert.csr \
    -out vault-cert.pem
## 新增用户
addgroup --system  vault   
/usr/sbin/adduser       --system       --gid 114       --home /srv/vault       --no-create-home       --shell /bin/false       vault 

## 配置文件

```
cluster_addr  = "https://vault.ragnarokrevival.com:8201"
api_addr      = "https://vault.ragnarokrevival.com:8200"
disable_mlock = true
ui            = true

listener "tcp" {
  address            = "0.0.0.0:8200"
  tls_cert_file      = "/root/vault/certs.d/vault-cert.pem"
  tls_key_file       = "/root/vault/certs.d/vault-key.pem"
  tls_client_ca_file = "/root/vault/certs.d/vault-ca.pem"
}


storage "raft" {
  path    = "/opt/vault/data"
  node_id = "node-1"

  retry_join {
    leader_tls_servername   = "vault.ragnarokrevival.com"
    leader_api_addr         = "https://12.0.0.40:8200"
    leader_ca_cert_file     = "/root/vault/certs.d/vault-ca.pem"
    leader_client_cert_file = "/root/vault/certs.d/vault-cert.pem"
    leader_client_key_file  = "/root/vault/certs.d/vault-key.pem"
  }
}

```
## 报错解决
```
由于我们不使用 TLS，因此请将 VAULT_ADDR 设置为使用 HTTP 而不是 HTTPS，并将环境值保存到某用户 的 .bashrc 文件中。
export VAULT_ADDR='https://vault.ragnarokrevival.com:8200'
export VAULT_CAPATH='/root/vault/certs.d/vault-cert.pem'
```
## Command
```
#显示集群成员及其角色
vault  operator  raft list-peers
#

```

